import sqlite3, secrets, csv, io, os
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort, make_response
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR=os.path.dirname(os.path.abspath(__file__))
DB_PATH=os.path.join(APP_DIR,"ff_arena.db")
app=Flask(__name__)
app.secret_key="CHANGE_THIS_SECRET_KEY_TO_A_LONG_RANDOM_VALUE"
app.config["SESSION_COOKIE_HTTPONLY"]=True
app.config["SESSION_COOKIE_SAMESITE"]="Lax"

def conn():
    c=sqlite3.connect(DB_PATH)
    c.row_factory=sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS tournaments(
          id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,description TEXT DEFAULT '',
          mode TEXT NOT NULL, map_name TEXT DEFAULT 'Bermuda', match_type TEXT DEFAULT 'Battle Royale',
          event_date TEXT NOT NULL, registration_deadline TEXT DEFAULT '',
          entry_fee TEXT DEFAULT 'Free', prize_pool TEXT DEFAULT '0',
          slots INTEGER NOT NULL DEFAULT 48,status TEXT NOT NULL DEFAULT 'Upcoming',
          room_id TEXT DEFAULT '',room_pass TEXT DEFAULT '',room_visible INTEGER DEFAULT 0,
          rules TEXT DEFAULT '',result_note TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS players(
          id INTEGER PRIMARY KEY AUTOINCREMENT,tournament_id INTEGER NOT NULL,
          player_name TEXT NOT NULL,uid TEXT NOT NULL,team_name TEXT DEFAULT '',
          phone TEXT DEFAULT '',registered_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
          UNIQUE(tournament_id,uid)
        );
        CREATE TABLE IF NOT EXISTS scores(
          id INTEGER PRIMARY KEY AUTOINCREMENT,tournament_id INTEGER NOT NULL,
          player_id INTEGER NOT NULL,rank_no INTEGER DEFAULT 0,kills INTEGER DEFAULT 0,
          points INTEGER DEFAULT 0,notes TEXT DEFAULT '',
          FOREIGN KEY(tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
          FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE,
          UNIQUE(tournament_id,player_id)
        );
        CREATE TABLE IF NOT EXISTS notices(
          id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,body TEXT NOT NULL,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """)
        if not c.execute("SELECT id FROM admins LIMIT 1").fetchone():
            c.execute("INSERT INTO admins(username,password_hash) VALUES (?,?)",
                      ("admin",generate_password_hash("admin123")))
        if not c.execute("SELECT id FROM notices LIMIT 1").fetchone():
            c.execute("INSERT INTO notices(title,body) VALUES (?,?)",
                      ("Welcome to FF Arena","Tournament announcements will appear here."))
init_db()

def csrf_token():
    if "csrf" not in session: session["csrf"]=secrets.token_hex(24)
    return session["csrf"]
app.jinja_env.globals["csrf_token"]=csrf_token

@app.before_request
def csrf_check():
    if request.method=="POST":
        token=request.form.get("_csrf","")
        if not token or token!=session.get("csrf"):
            abort(400,"Invalid form token. Please refresh and try again.")

def admin_only(fn):
    @wraps(fn)
    def inner(*a,**kw):
        if not session.get("admin_id"): return redirect(url_for("admin_login"))
        return fn(*a,**kw)
    return inner

def get_tournament(tid):
    with conn() as c: t=c.execute("SELECT * FROM tournaments WHERE id=?",(tid,)).fetchone()
    return t

@app.route("/")
def home():
    q=request.args.get("q","").strip()
    with conn() as c:
        if q:
            ts=c.execute("SELECT * FROM tournaments WHERE title LIKE ? ORDER BY id DESC",("%"+q+"%",)).fetchall()
        else: ts=c.execute("SELECT * FROM tournaments ORDER BY id DESC").fetchall()
        notices=c.execute("SELECT * FROM notices ORDER BY id DESC LIMIT 5").fetchall()
        counts={r["status"]:r["n"] for r in c.execute("SELECT status,COUNT(*) n FROM tournaments GROUP BY status")}
    return render_template("home.html",tournaments=ts,notices=notices,counts=counts,q=q)

@app.route("/t/<int:tid>")
def tournament_detail(tid):
    t=get_tournament(tid)
    if not t: abort(404)
    with conn() as c:
        players=c.execute("SELECT * FROM players WHERE tournament_id=? ORDER BY registered_at",(tid,)).fetchall()
        scores=c.execute("""SELECT p.player_name,p.uid,p.team_name,s.rank_no,s.kills,s.points,s.notes
                            FROM scores s JOIN players p ON p.id=s.player_id
                            WHERE s.tournament_id=? ORDER BY s.points DESC,s.kills DESC,s.rank_no ASC""",(tid,)).fetchall()
    return render_template("detail.html",t=t,players=players,scores=scores)

@app.route("/register/<int:tid>",methods=["POST"])
def register(tid):
    t=get_tournament(tid)
    if not t: abort(404)
    name=request.form.get("player_name","").strip()
    uid=request.form.get("uid","").strip()
    team=request.form.get("team_name","").strip()
    phone=request.form.get("phone","").strip()
    if not name or not uid:
        flash("Player name এবং UID আবশ্যক।","error")
    elif t["status"]!="Upcoming" or (t["registration_deadline"] and t["registration_deadline"]<datetime.now().strftime("%Y-%m-%dT%H:%M")):
        flash("Registration বন্ধ।","error")
    else:
        with conn() as c:
            n=c.execute("SELECT COUNT(*) FROM players WHERE tournament_id=?",(tid,)).fetchone()[0]
            if n>=t["slots"]: flash("Slots পূর্ণ হয়ে গেছে।","error")
            else:
                try:
                    c.execute("INSERT INTO players(tournament_id,player_name,uid,team_name,phone) VALUES(?,?,?,?,?)",(tid,name,uid,team,phone))
                    flash("Registration সফল!","success")
                except sqlite3.IntegrityError: flash("এই UID আগেই register করা হয়েছে।","error")
    return redirect(url_for("tournament_detail",tid=tid)+"#register")

@app.route("/admin/login",methods=["GET","POST"])
def admin_login():
    if request.method=="POST":
        with conn() as c: a=c.execute("SELECT * FROM admins WHERE username=?",(request.form.get("username",""),)).fetchone()
        if a and check_password_hash(a["password_hash"],request.form.get("password","")):
            session.clear();session["admin_id"]=a["id"];session["csrf"]=secrets.token_hex(24)
            return redirect(url_for("dashboard"))
        flash("Login তথ্য ভুল।","error")
    return render_template("login.html")

@app.route("/admin/logout",methods=["POST"])
@admin_only
def admin_logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/admin")
@admin_only
def dashboard():
    with conn() as c:
        stats={
          "tournaments":c.execute("SELECT COUNT(*) FROM tournaments").fetchone()[0],
          "players":c.execute("SELECT COUNT(*) FROM players").fetchone()[0],
          "live":c.execute("SELECT COUNT(*) FROM tournaments WHERE status='Live'").fetchone()[0],
          "upcoming":c.execute("SELECT COUNT(*) FROM tournaments WHERE status='Upcoming'").fetchone()[0],
        }
        ts=c.execute("SELECT * FROM tournaments ORDER BY id DESC").fetchall()
    return render_template("dashboard.html",stats=stats,tournaments=ts)

@app.route("/admin/tournament/new",methods=["GET","POST"])
@app.route("/admin/tournament/<int:tid>/edit",methods=["GET","POST"])
@admin_only
def tournament_form(tid=None):
    t=get_tournament(tid) if tid else None
    if tid and not t: abort(404)
    if request.method=="POST":
        f=request.form
        vals=(f.get("title","").strip(),f.get("description",""),f.get("mode","Squad"),
              f.get("map_name","Bermuda"),f.get("match_type","Battle Royale"),f.get("event_date",""),
              f.get("registration_deadline",""),f.get("entry_fee","Free"),f.get("prize_pool","0"),
              int(f.get("slots",48)),f.get("status","Upcoming"),f.get("room_id",""),f.get("room_pass",""),
              1 if f.get("room_visible") else 0,f.get("rules",""),f.get("result_note",""))
        if not vals[0] or not vals[5]:
            flash("Tournament title এবং date আবশ্যক।","error")
            return render_template("tournament_form.html",t=t)
        with conn() as c:
            if tid:
                c.execute("""UPDATE tournaments SET title=?,description=?,mode=?,map_name=?,match_type=?,event_date=?,
                  registration_deadline=?,entry_fee=?,prize_pool=?,slots=?,status=?,room_id=?,room_pass=?,room_visible=?,
                  rules=?,result_note=? WHERE id=?""",vals+(tid,))
            else:
                c.execute("""INSERT INTO tournaments(title,description,mode,map_name,match_type,event_date,
                  registration_deadline,entry_fee,prize_pool,slots,status,room_id,room_pass,room_visible,rules,result_note)
                  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",vals)
        flash("Tournament saved!","success")
        return redirect(url_for("dashboard"))
    return render_template("tournament_form.html",t=t)

@app.route("/admin/tournament/<int:tid>/delete",methods=["POST"])
@admin_only
def tournament_delete(tid):
    with conn() as c:c.execute("DELETE FROM tournaments WHERE id=?",(tid,))
    flash("Tournament delete হয়েছে।","success")
    return redirect(url_for("dashboard"))

@app.route("/admin/tournament/<int:tid>/players")
@admin_only
def manage_players(tid):
    t=get_tournament(tid)
    if not t: abort(404)
    with conn() as c:
        ps=c.execute("""SELECT p.*,s.rank_no,s.kills,s.points FROM players p LEFT JOIN scores s
            ON s.player_id=p.id AND s.tournament_id=p.tournament_id WHERE p.tournament_id=?
            ORDER BY p.registered_at""",(tid,)).fetchall()
    return render_template("players.html",t=t,players=ps)

@app.route("/admin/tournament/<int:tid>/score",methods=["POST"])
@admin_only
def score_save(tid):
    with conn() as c:
        for p in c.execute("SELECT id FROM players WHERE tournament_id=?",(tid,)).fetchall():
            pid=p["id"];rank=int(request.form.get(f"rank_{pid}",0) or 0)
            kills=int(request.form.get(f"kills_{pid}",0) or 0)
            points=int(request.form.get(f"points_{pid}",0) or 0)
            note=request.form.get(f"note_{pid}","")
            c.execute("""INSERT INTO scores(tournament_id,player_id,rank_no,kills,points,notes)
                VALUES(?,?,?,?,?,?) ON CONFLICT(tournament_id,player_id) DO UPDATE SET
                rank_no=excluded.rank_no,kills=excluded.kills,points=excluded.points,notes=excluded.notes""",
                (tid,pid,rank,kills,points,note))
    flash("Scores saved.","success")
    return redirect(url_for("manage_players",tid=tid))

@app.route("/admin/tournament/<int:tid>/export")
@admin_only
def export_players(tid):
    t=get_tournament(tid)
    if not t: abort(404)
    with conn() as c: ps=c.execute("SELECT player_name,uid,team_name,phone,registered_at FROM players WHERE tournament_id=?",(tid,)).fetchall()
    out=io.StringIO();w=csv.writer(out);w.writerow(["Name","UID","Team","Phone","Registered"])
    w.writerows([tuple(p) for p in ps])
    resp=make_response(out.getvalue());resp.headers["Content-Type"]="text/csv; charset=utf-8"
    resp.headers["Content-Disposition"]=f'attachment; filename="tournament_{tid}_players.csv"'
    return resp

@app.route("/admin/password",methods=["GET","POST"])
@admin_only
def change_password():
    if request.method=="POST":
        old=request.form.get("old","");new=request.form.get("new","")
        with conn() as c:a=c.execute("SELECT * FROM admins WHERE id=?",(session["admin_id"],)).fetchone()
        if not check_password_hash(a["password_hash"],old):flash("বর্তমান password ভুল।","error")
        elif len(new)<8:flash("নতুন password কমপক্ষে ৮ অক্ষর দিন।","error")
        else:
            with conn() as c:c.execute("UPDATE admins SET password_hash=? WHERE id=?",(generate_password_hash(new),a["id"]))
            flash("Password changed.","success");return redirect(url_for("dashboard"))
    return render_template("password.html")

@app.route("/admin/notices",methods=["GET","POST"])
@admin_only
def notices_admin():
    if request.method=="POST":
        title=request.form.get("title","").strip();body=request.form.get("body","").strip()
        if title and body:
            with conn() as c:c.execute("INSERT INTO notices(title,body) VALUES(?,?)",(title,body))
            flash("Notice posted.","success")
        return redirect(url_for("notices_admin"))
    with conn() as c:ns=c.execute("SELECT * FROM notices ORDER BY id DESC").fetchall()
    return render_template("notices.html",notices=ns)

@app.route("/admin/notice/<int:nid>/delete",methods=["POST"])
@admin_only
def notice_delete(nid):
    with conn() as c:c.execute("DELETE FROM notices WHERE id=?",(nid,))
    return redirect(url_for("notices_admin"))

if __name__=="__main__":
    print("FF Arena running at http://127.0.0.1:5000")
    app.run(host="0.0.0.0",port=5000,debug=False)
