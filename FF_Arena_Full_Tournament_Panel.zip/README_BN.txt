FF ARENA FULL TOURNAMENT PANEL — বাংলা গাইড

প্রজেক্টে আছে:
- Public tournament website, search, tournament details
- Registration, UID duplicate check, slot limit ও deadline
- Admin login, dashboard, tournament CRUD, status control
- Room details publish toggle
- Player list, score/rank/kills/points entry, leaderboard
- CSV export
- Notice board
- Admin password change
- SQLite persistent database
- CSRF form protection, password hashing, mobile-responsive design

TERMUX INSTALL:
1) pkg update -y
2) pkg install python -y
3) ZIP extract করে folder-এ ঢুকুন
4) pip install -r requirements.txt
5) python app.py
6) Android browser-এ: http://127.0.0.1:5000

ADMIN:
http://127.0.0.1:5000/admin/login
Fresh install starter login:
username: admin
password: admin123
Login করে Change password থেকে password বদলান।

LAN:
Termux-এ server চালু রেখে একই Wi-Fi network থেকে ফোনের local IP:
http://PHONE_LOCAL_IP:5000

SECURITY NOTE:
Public internet-এ সরাসরি এই development server প্রকাশ করবেন না।
Secret key বদলান, default password বদলান, HTTPS ও production WSGI server ব্যবহার করুন।
Player phone তথ্য optional—privacy দরকার হলে ফোন নম্বর সংগ্রহ না করাই ভালো।
Payments/automatic prize transfer নেই। Tournament পরিচালনার manual tool।
